</main>
<footer class="mt-8 py-4 bg-gray-100 border-t text-center text-gray-500 text-sm">
    &copy; <?= date('Y') ?> WhatsApp API Admin Panel. All rights reserved.
</footer>
</body>
</html>