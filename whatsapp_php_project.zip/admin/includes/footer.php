  <footer class="text-center mt-5 mb-3 text-muted">
    &copy; <?= date("Y") ?> WhatsApp API Panel
  </footer>
</body>
</html>
