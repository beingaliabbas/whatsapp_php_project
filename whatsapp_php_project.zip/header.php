<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include_once "functions.php"; // Make sure this file defines getSetting()

// Fetch base_url from general settings using getSetting()
$base_url = rtrim(getSetting('base_url'), '/') . '/';

$isLoggedIn = isset($_SESSION['user_id']);
$username = $isLoggedIn && isset($_SESSION['username']) ? $_SESSION['username'] : '';
$logo_path = $base_url . "assets/logo.png";
?>

<nav class="bg-white shadow-sm">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex items-center">
                <a href="<?= $base_url ?>" class="flex items-center space-x-2">
                    <img src="<?= htmlspecialchars($logo_path) ?>" alt="WhatsApp API Logo" class="h-8 w-auto">
                    <!-- Optionally, add: <span class="sr-only">WhatsApp API</span> -->
                </a>
            </div>
            <div class="flex items-center space-x-4">
                <?php if ($isLoggedIn): ?>
                    <span class="text-gray-700 font-medium">
                        Hello, <?= htmlspecialchars($username) ?>
                    </span>
                    <a href="<?= $base_url ?>account" class="no-underline px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition">
                        Your account
                    </a>
                    <a href="<?= $base_url ?>logout" class="no-underline px-4 py-2 text-gray-600 hover:text-indigo-600 transition">
                        Logout
                    </a>
                <?php else: ?>
                    <a href="<?= $base_url ?>login" class="no-underline px-4 py-2 text-indigo-600 hover:text-indigo-800 transition">
                        Login
                    </a>
                    <a href="<?= $base_url ?>register" class="no-underline px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition">
                        Register
                    </a>
                <?php endif; ?>
                <button id="theme-toggle" class="p-2 rounded-full focus:outline-none hidden">
                    <i class="fas fa-moon"></i>
                </button>
            </div>
        </div>
    </div>
</nav>